export interface ScoreEntry {
  score: number;
  wave: number;
  date: string;
}

const KEY = "newton-apple-lab-scores-v1";

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const list = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(list)) return [];
    return list
      .filter((e) => typeof e?.score === "number" && typeof e?.wave === "number")
      .slice(0, 5);
  } catch {
    return [];
  }
}

export function bestScore(): number {
  const list = loadScores();
  return list.length ? list[0].score : 0;
}

/** 写入成绩，返回新榜单与本条名次（-1 表示未上榜） */
export function saveScore(score: number, wave: number): { list: ScoreEntry[]; index: number } {
  const now = new Date();
  const date = `${String(now.getMonth() + 1).padStart(2, "0")}-${String(
    now.getDate()
  ).padStart(2, "0")}`;
  const entry: ScoreEntry = { score, wave, date };
  const all = [...loadScores(), entry]
    .sort((a, b) => b.score - a.score || b.wave - a.wave)
    .slice(0, 5);
  try {
    localStorage.setItem(KEY, JSON.stringify(all));
  } catch {
    /* ignore */
  }
  return { list: all, index: all.indexOf(entry) };
}
