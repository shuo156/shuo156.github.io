import * as Matter from "matter-js";
import { sfx } from "./audio";
import { loadScores, saveScore, bestScore, type ScoreEntry } from "./scores";

const { Engine, Composite, Bodies, Body, Events, Constraint, Bounds, Vertices } = Matter;

/* ---------------- 常量 ---------------- */
const STEP = 1000 / 60;
const PPM = 100; // 像素/米（读数换算）
const G_UNITS = 0.98; // matter 重力单位 → 约 9.8 m/s²
const BALL_R = 12;
const APPLE_R = 15;
const CRATE = 54;
const MAX_LAUNCH = 1600; // px/s
const MIN_LAUNCH = 300;
const DRAG_K = 6.4; // 拖拽像素 → 初速度
const START_BALLS = 10;

export type Screen = "menu" | "playing" | "paused" | "over";

export interface HudSnapshot {
  screen: Screen;
  score: number;
  wave: number;
  balls: number;
  targets: number;
  wind: number; // matter 单位，×10 = m/s²
  combo: number;
  comboMult: number;
  comboOn: boolean;
  shots: number;
  hits: number;
  maxCombo: number;
  bounceHits: number;
  hasFired: boolean;
  banner: { title: string; sub: string; id: number } | null;
  scores: ScoreEntry[];
  newBestIndex: number;
  best: number;
}

interface Meta {
  kind: "crate" | "plank" | "apple" | "ball" | "ground" | "stand";
  hp?: number;
  maxHp?: number;
  bounces?: number;
  rest?: number;
  seed?: number;
  constraint?: Matter.Constraint;
  anchor?: { x: number; y: number };
  dead?: boolean;
}
type B = Matter.Body & { meta?: Meta };

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  g: number;
  drag: number;
  rot: number;
  vr: number;
  life: number;
  max: number;
  size: number;
  color: string;
  kind: "dot" | "chip" | "spark" | "ring" | "smoke" | "confetti" | "streak";
}

interface Floater {
  x: number;
  y: number;
  text: string;
  sub?: string;
  color: string;
  t: number;
  max: number;
  size: number;
}

const INK = "#1e2a4a";
const PAPER = "#f3f5fa";
const RED = "#d93a3a";
const KRAFT = "#dca967";
const KRAFT_D = "#c3904f";
const YELLOW = "#ffd23f";

const rnd = (a = 1, b?: number) => (b === undefined ? Math.random() * a : a + Math.random() * (b - a));

export class PhysicsGame {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private onHud: (h: HudSnapshot) => void;

  private engine!: Matter.Engine;
  private worldW = 1280;
  private worldH = 720;
  private viewW = 1280;
  private viewH = 720;
  private scale = 1;
  private dpr = 1;
  private gridTile: HTMLCanvasElement | null = null;

  screen: Screen = "menu";
  private score = 0;
  private wave = 1;
  private ballsLeft = START_BALLS;
  private targetsLeft = 0;
  private wind = 0;
  private combo = 0;
  private comboTimer = 0;
  private shots = 0;
  private hits = 0;
  private maxCombo = 0;
  private bounceHits = 0;
  private hasFired = false;
  private banner: HudSnapshot["banner"] = null;
  private bannerId = 0;
  private newBestIndex = -1;
  private recordAnnounced = false;

  private aimAngle = 52; // 与水平夹角
  private aimPower = 950; // px/s
  private recoil = 0;
  private shake = 0;
  private freeze = 0;
  private cooldown = 0;
  private waveClearTimer = -1;
  private overTimer = -1;
  private comboFlash = 0;

  private balls: B[] = [];
  private particles: Particle[] = [];
  private floaters: Floater[] = [];
  private keys = new Set<string>();
  private aiming = false;
  private aimPointerId = -1;
  private aimStart = { x: 0, y: 0 };
  private aimNow = { x: 0, y: 0 };

  private raf = 0;
  private last = 0;
  private acc = 0;
  private running = false;
  private lastHudJson = "";

  private detachFns: Array<() => void> = [];

  constructor(canvas: HTMLCanvasElement, onHud: (h: HudSnapshot) => void) {
    this.canvas = canvas;
    this.onHud = onHud;
    this.ctx = canvas.getContext("2d")!;
  }

  /* ---------------- 生命周期 ---------------- */
  attach() {
    this.engine = Engine.create({ enableSleeping: false });
    (this.engine as unknown as { gravity: { x: number; y: number; scale: number } }).gravity.y =
      G_UNITS;

    Events.on(this.engine, "collisionStart", this.onCollision as never);

    const onResize = () => this.resize();
    const onVis = () => {
      if (document.hidden && this.screen === "playing") this.pause();
    };
    const onKey = (e: KeyboardEvent) => this.onKeyDown(e);
    const onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    const onCtx = (e: Event) => e.preventDefault();

    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKeyUp);
    this.canvas.addEventListener("contextmenu", onCtx);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.canvas.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("pointercancel", this.onPointerUp);

    this.detachFns = [
      () => window.removeEventListener("resize", onResize),
      () => window.removeEventListener("orientationchange", onResize),
      () => document.removeEventListener("visibilitychange", onVis),
      () => window.removeEventListener("keydown", onKey),
      () => window.removeEventListener("keyup", onKeyUp),
      () => this.canvas.removeEventListener("contextmenu", onCtx),
      () => this.canvas.removeEventListener("pointerdown", this.onPointerDown),
      () => this.canvas.removeEventListener("pointermove", this.onPointerMove),
      () => window.removeEventListener("pointerup", this.onPointerUp),
      () => window.removeEventListener("pointercancel", this.onPointerUp),
    ];

    this.resize();
    this.buildWave(1);
    this.running = true;
    this.last = performance.now();
    const loop = (now: number) => {
      if (!this.running) return;
      this.raf = requestAnimationFrame(loop);
      this.tick(now);
    };
    this.raf = requestAnimationFrame(loop);
    this.pushHud();
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.detachFns.forEach((f) => f());
    this.detachFns = [];
    if (this.engine) {
      Events.off(this.engine, "collisionStart", this.onCollision as never);
      Composite.clear(this.engine.world, false);
    }
  }

  /* ---------------- 布局 ---------------- */
  private resize() {
    const cssW = this.canvas.clientWidth || window.innerWidth;
    const cssH = this.canvas.clientHeight || window.innerHeight;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(cssW * this.dpr);
    this.canvas.height = Math.round(cssH * this.dpr);
    const aspect = cssW / cssH;
    if (aspect >= 620 / 720) {
      this.worldH = 720;
      this.worldW = Math.min(720 * aspect, 1700);
      this.scale = cssH / 720;
    } else {
      this.worldW = 620;
      this.worldH = 620 / aspect;
      this.scale = cssW / 620;
    }
    this.viewW = cssW / this.scale;
    this.viewH = cssH / this.scale;
    this.gridTile = this.makeGridTile();
    // 重建当前波（保留分数/弹药/波数）
    if (this.engine) {
      const w = this.wave;
      this.buildWave(w);
    }
  }

  private makeGridTile(): HTMLCanvasElement {
    const c = document.createElement("canvas");
    c.width = 130;
    c.height = 130;
    const g = c.getContext("2d")!;
    g.fillStyle = PAPER;
    g.fillRect(0, 0, 130, 130);
    g.strokeStyle = "#dde6f5";
    g.lineWidth = 1;
    for (let i = 26; i < 130; i += 26) {
      g.beginPath();
      g.moveTo(i + 0.5, 0);
      g.lineTo(i + 0.5, 130);
      g.moveTo(0, i + 0.5);
      g.lineTo(130, i + 0.5);
      g.stroke();
    }
    g.strokeStyle = "#c8d7f0";
    g.lineWidth = 1.6;
    g.strokeRect(0.5, 0.5, 130, 130);
    return c;
  }

  private groundY() {
    return this.worldH - 36;
  }
  private cannonPos() {
    return { x: 88, y: this.groundY() - 8 };
  }

  /* ---------------- 输入 ---------------- */
  private toWorld(e: PointerEvent) {
    const rect = this.canvas.getBoundingClientRect();
    return { x: (e.clientX - rect.left) / this.scale, y: (e.clientY - rect.top) / this.scale };
  }

  private onPointerDown = (e: PointerEvent) => {
    sfx.unlock();
    if (this.screen !== "playing") return;
    e.preventDefault();
    if (this.aimPointerId !== -1) return;
    this.aimPointerId = e.pointerId;
    this.aiming = true;
    const p = this.toWorld(e);
    this.aimStart = p;
    this.aimNow = p;
    try {
      this.canvas.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.aiming || e.pointerId !== this.aimPointerId) return;
    this.aimNow = this.toWorld(e);
    const dx = this.aimNow.x - this.aimStart.x;
    const dy = this.aimNow.y - this.aimStart.y;
    const len = Math.hypot(dx, dy);
    if (len > 10) {
      const ang = (Math.atan2(-dy, dx) * 180) / Math.PI;
      this.aimAngle = Math.max(10, Math.min(89, ang));
      this.aimPower = Math.max(MIN_LAUNCH, Math.min(MAX_LAUNCH, len * DRAG_K));
    }
  };

  private onPointerUp = (e: PointerEvent) => {
    if (e.pointerId !== this.aimPointerId) return;
    this.aimPointerId = -1;
    if (!this.aiming) return;
    this.aiming = false;
    if (this.screen !== "playing") return;
    const dx = this.aimNow.x - this.aimStart.x;
    const dy = this.aimNow.y - this.aimStart.y;
    // 轻点 → 按当前键盘瞄准参数发射；拖动 → 按拖动矢量发射
    this.fire();
    void dx;
    void dy;
  };

  private onKeyDown(e: KeyboardEvent) {
    const c = e.code;
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Space"].includes(c))
      e.preventDefault();
    if (e.repeat) {
      this.keys.add(c);
      return;
    }
    this.keys.add(c);
    sfx.unlock();

    if (c === "Space") {
      if (this.screen === "playing") this.fire();
      else if (this.screen === "menu") this.startGame();
      else if (this.screen === "over") this.restart();
    }
    if (c === "Enter") {
      if (this.screen === "menu") this.startGame();
      else if (this.screen === "over") this.restart();
    }
    if (c === "KeyP" || c === "Escape") {
      if (this.screen === "playing") this.pause();
      else if (this.screen === "paused") this.resume();
    }
    if (c === "KeyR") {
      if (this.screen !== "menu") this.restart();
    }
  }

  /* ---------------- 流程 ---------------- */
  startGame() {
    sfx.click();
    this.restart();
  }

  restart() {
    this.score = 0;
    this.wave = 1;
    this.ballsLeft = START_BALLS;
    this.combo = 0;
    this.comboTimer = 0;
    this.shots = 0;
    this.hits = 0;
    this.maxCombo = 0;
    this.bounceHits = 0;
    this.hasFired = false;
    this.newBestIndex = -1;
    this.recordAnnounced = false;
    this.particles.length = 0;
    this.floaters.length = 0;
    this.waveClearTimer = -1;
    this.overTimer = -1;
    this.aimAngle = 52;
    this.aimPower = 950;
    this.buildWave(1);
    this.screen = "playing";
    this.setBanner("第 1 波", "热身局 · 无风 · 弹药 ×10");
    sfx.wave();
    this.pushHud();
  }

  pause() {
    if (this.screen !== "playing") return;
    this.screen = "paused";
    sfx.click();
    this.pushHud();
  }
  resume() {
    if (this.screen !== "paused") return;
    this.screen = "playing";
    sfx.click();
    this.last = performance.now();
    this.pushHud();
  }
  toMenu() {
    this.screen = "menu";
    this.buildWave(1);
    sfx.click();
    this.pushHud();
  }

  private setBanner(title: string, sub: string) {
    this.banner = { title, sub, id: ++this.bannerId };
  }

  private windText() {
    if (Math.abs(this.wind) < 0.001) return "无风";
    const ms = Math.abs(this.wind * 10).toFixed(1);
    return `风速 ${ms} m/s² ${this.wind > 0 ? "→" : "←"}`;
  }

  /* ---------------- 波次搭建 ---------------- */
  private clearWorld() {
    Composite.clear(this.engine.world, false);
    this.balls = [];
  }

  private buildWave(w: number) {
    this.clearWorld();
    this.wind =
      w >= 2 ? Math.min(0.05 + w * 0.016, 0.19) * (Math.random() < 0.5 ? -1 : 1) : 0;
    (this.engine as unknown as { gravity: { x: number } }).gravity.x = this.wind;

    const gy = this.groundY();
    const ground = Bodies.rectangle(this.worldW / 2, gy + 40, this.worldW * 4, 80, {
      isStatic: true,
      friction: 0.8,
      restitution: 0.25,
    }) as B;
    ground.meta = { kind: "ground" };
    Composite.add(this.engine.world, ground);

    const zone0 = this.worldW * 0.5;
    const zone1 = this.worldW * 0.94;
    const zoneW = zone1 - zone0;
    let targets = Math.min(3 + (w - 1), 8);
    targets = Math.min(targets, Math.max(3, Math.floor(zoneW / 108)));

    const patterns: Array<"stack" | "bridge" | "stand" | "wall"> = [];
    for (let i = 0; i < targets; i++) {
      if (w === 1) patterns.push(i === 0 ? "stack" : i === 1 ? "stand" : "stack");
      else {
        const pool: Array<"stack" | "bridge" | "stand" | "wall"> = [
          "stack",
          "bridge",
          "stand",
          "wall",
          "stack",
        ];
        patterns.push(pool[Math.floor(Math.random() * pool.length)]);
      }
    }
    this.targetsLeft = 0;
    for (let i = 0; i < targets; i++) {
      const cx = zone0 + ((i + 0.5) * zoneW) / targets + rnd(-14, 14);
      this.addTower(cx, patterns[i], w);
    }
    if (w >= 3) this.addTower(zone1 - 20, "stand", w); // 加一个远处吊靶
    this.pushHud();
  }

  private addCrate(x: number, y: number, plank = false): B {
    const body = (
      plank
        ? Bodies.rectangle(x, y, 150, 16, { density: 0.0014, friction: 0.7, restitution: 0.05 })
        : Bodies.rectangle(x, y, CRATE, CRATE, { density: 0.0016, friction: 0.65, restitution: 0.06 })
    ) as B;
    body.meta = {
      kind: plank ? "plank" : "crate",
      hp: plank ? 2 : 3,
      maxHp: plank ? 2 : 3,
      seed: Math.random(),
    };
    Composite.add(this.engine.world, body);
    return body;
  }

  private addApple(x: number, y: number, hang?: { ax: number; ay: number; len: number }) {
    const apple = Bodies.circle(x, y, APPLE_R, {
      density: 0.0012,
      friction: 0.4,
      restitution: 0.3,
    }) as B;
    apple.meta = { kind: "apple", seed: Math.random() };
    Composite.add(this.engine.world, apple);
    if (hang) {
      const c = Constraint.create({
        pointA: { x: hang.ax, y: hang.ay },
        bodyB: apple,
        length: hang.len,
        stiffness: 0.9,
        damping: 0.03,
      });
      apple.meta.constraint = c;
      apple.meta.anchor = { x: hang.ax, y: hang.ay };
      Composite.add(this.engine.world, c);
    }
    this.targetsLeft++;
  }

  private addTower(cx: number, type: "stack" | "bridge" | "stand" | "wall", w: number) {
    const gy = this.groundY();
    if (type === "stack") {
      const h = Math.min(2 + Math.floor(rnd(0, 2)) + Math.floor(w / 3), 5);
      for (let i = 0; i < h; i++) this.addCrate(cx + rnd(-3, 3), gy - CRATE / 2 - i * CRATE);
      this.addApple(cx, gy - h * CRATE - APPLE_R - 2);
    } else if (type === "bridge") {
      const h = 2 + (w >= 4 ? 1 : 0);
      this.addCrate(cx - 56, gy - CRATE / 2);
      this.addCrate(cx + 56, gy - CRATE / 2);
      if (h > 2) {
        this.addCrate(cx - 56, gy - CRATE * 1.5);
        this.addCrate(cx + 56, gy - CRATE * 1.5);
      }
      this.addCrate(cx, gy - h * CRATE - 8, true); // 木板桥面
      this.addApple(cx, gy - APPLE_R - 2); // 桥洞里的苹果
    } else if (type === "stand") {
      // 铁架台 + 悬挂苹果
      const poleX = cx + 46;
      const topY = gy - 158;
      const pole = Bodies.rectangle(poleX, gy - 75, 10, 150, { isStatic: true }) as B;
      pole.meta = { kind: "stand" };
      const arm = Bodies.rectangle(poleX - 42, topY + 4, 92, 9, { isStatic: true }) as B;
      arm.meta = { kind: "stand" };
      Composite.add(this.engine.world, [pole, arm]);
      const ax = poleX - 80;
      this.addApple(ax, topY + 9 + 58, { ax, ay: topY + 9, len: 58 });
    } else {
      // 围墙后的苹果：需要吊高抛物线
      const wallH = 2 + (w >= 3 ? 1 : 0);
      for (let i = 0; i < wallH; i++) this.addCrate(cx - 62, gy - CRATE / 2 - i * CRATE);
      this.addApple(cx + 8, gy - APPLE_R - 2);
    }
  }

  /* ---------------- 发射 ---------------- */
  private fire() {
    if (this.screen !== "playing" || this.cooldown > 0 || this.ballsLeft <= 0) return;
    this.cooldown = 0.16;
    this.hasFired = true;
    this.ballsLeft--;
    this.shots++;

    const { x: cx, y: cy } = this.cannonPos();
    const a = (this.aimAngle * Math.PI) / 180;
    const v = this.aimPower;
    const mx = cx + Math.cos(a) * 70;
    const my = cy - Math.sin(a) * 70;
    const ball = Bodies.circle(mx, my, BALL_R, {
      density: 0.0042,
      friction: 0.04,
      restitution: 0.55,
      frictionAir: 0.0006,
    }) as B;
    ball.meta = { kind: "ball", bounces: 0, rest: 0 };
    Body.setVelocity(ball, { x: (Math.cos(a) * v) / 60, y: (-Math.sin(a) * v) / 60 });
    Composite.add(this.engine.world, ball);
    this.balls.push(ball);
    if (this.balls.length > 7) {
      const old = this.balls.shift()!;
      this.removeBall(old);
    }

    this.recoil = 10;
    this.shake = Math.min(this.shake + 3, 14);
    // 炮口烟
    for (let i = 0; i < 10; i++) {
      const sa = a + rnd(-0.5, 0.5);
      this.spawn({
        x: mx,
        y: my,
        vx: Math.cos(sa) * rnd(60, 240),
        vy: -Math.sin(sa) * rnd(60, 240),
        g: -30,
        drag: 3.2,
        life: rnd(0.25, 0.5),
        size: rnd(3, 7),
        color: "#8d99bd",
        kind: "smoke",
      });
    }
    this.spawn({
      x: mx,
      y: my,
      vx: 0,
      vy: 0,
      g: 0,
      drag: 0,
      life: 0.22,
      size: 26,
      color: YELLOW,
      kind: "ring",
    });
    sfx.launch(v / MAX_LAUNCH);
    this.pushHud();
  }

  private removeBall(b: B) {
    b.meta!.dead = true;
    Composite.remove(this.engine.world, b);
    this.balls = this.balls.filter((x) => x !== b);
  }

  /* ---------------- 碰撞 ---------------- */
  private onCollision = (ev: Matter.IEventCollision<Matter.Engine>) => {
    for (const pair of ev.pairs) {
      const a = pair.bodyA as B;
      const b = pair.bodyB as B;
      const ma = a.meta;
      const mb = b.meta;
      if (!ma || !mb || ma.dead || mb.dead) continue;
      const rel = Math.hypot(
        a.velocity.x - b.velocity.x,
        a.velocity.y - b.velocity.y
      ); // px/step

      const ka = ma.kind;
      const kb = mb.kind;

      // 小球 × 苹果：直接命中
      if ((ka === "ball" && kb === "apple") || (ka === "apple" && kb === "ball")) {
        const apple = ka === "apple" ? a : b;
        const ball = (ka === "ball" ? a : b) as B;
        this.destroyApple(apple, "direct", ball);
        continue;
      }
      // 苹果被坠落物砸中 / 摔地
      if (ka === "apple" || kb === "apple") {
        const apple = ka === "apple" ? a : b;
        const om = ka === "apple" ? mb : ma;
        if (
          (om.kind === "crate" || om.kind === "plank" || om.kind === "apple") &&
          rel > 2.3
        ) {
          this.destroyApple(apple, "chain");
          continue;
        }
        if (om.kind === "ground" && rel > 2.6) {
          this.destroyApple(apple, "fall");
          continue;
        }
      }
      // 小球 × 木箱：伤害 + 反弹计数
      if (ka === "ball" || kb === "ball") {
        const ball = ka === "ball" ? a : b;
        const bm = ka === "ball" ? ma : mb;
        const other = ka === "ball" ? b : a;
        if (rel > 1.3) {
          bm.bounces = (bm.bounces || 0) + 1;
          this.bounceFx(ball, rel);
        }
        if (bm.kind === "ground" && rel > 2.2) {
          sfx.bounce(rel);
          this.dust(ball.position.x, this.groundY(), Math.min(rel, 6));
        } else if (other.meta && (bm.kind === "crate" || bm.kind === "plank")) {
          if (rel > 2.1) this.damageCrate(other, rel > 3.8 ? 2 : 1, ball.position);
          if (rel > 2) sfx.thud(rel);
          this.shake = Math.min(this.shake + Math.min(rel * 0.5, 3), 16);
        } else if (bm.kind === "stand" && rel > 1.5) {
          sfx.bounce(rel * 0.8);
        }
        continue;
      }
      // 木箱重摔（与配对顺序无关）
      if (rel > 4.2) {
        const aFrag = ka === "crate" || ka === "plank";
        const bFrag = kb === "crate" || kb === "plank";
        if (aFrag && (bFrag || kb === "ground")) {
          this.damageCrate(a, 1, a.position);
          sfx.thud(rel * 0.7);
        } else if (bFrag && (aFrag || ka === "ground")) {
          this.damageCrate(b, 1, b.position);
          sfx.thud(rel * 0.7);
        }
      }
    }
  };

  private bounceFx(ball: B, rel: number) {
    for (let i = 0; i < 3; i++) {
      this.spawn({
        x: ball.position.x,
        y: ball.position.y,
        vx: rnd(-90, 90),
        vy: rnd(-140, -20),
        g: 500,
        drag: 1,
        life: 0.3,
        size: rnd(1.6, 2.8),
        color: INK,
        kind: "dot",
      });
    }
    if (rel > 2.4) sfx.bounce(rel);
  }

  private dust(x: number, y: number, power: number) {
    for (let i = 0; i < Math.min(power * 2, 10); i++) {
      this.spawn({
        x: x + rnd(-10, 10),
        y: y - 2,
        vx: rnd(-120, 120),
        vy: rnd(-90, -20),
        g: 240,
        drag: 2.4,
        life: rnd(0.3, 0.55),
        size: rnd(2.5, 5),
        color: "#a8b4d4",
        kind: "smoke",
      });
    }
  }

  private damageCrate(c: B, dmg: number, at: { x: number; y: number }) {
    if (!c.meta || c.meta.dead) return;
    c.meta.hp = (c.meta.hp ?? 1) - dmg;
    // 木屑
    for (let i = 0; i < 5; i++) {
      this.spawn({
        x: at.x,
        y: at.y,
        vx: rnd(-180, 180),
        vy: rnd(-240, -40),
        g: 620,
        drag: 0.6,
        rot: rnd(0, 6.3),
        vr: rnd(-9, 9),
        life: rnd(0.35, 0.6),
        size: rnd(3, 6),
        color: Math.random() < 0.5 ? KRAFT : KRAFT_D,
        kind: "chip",
      });
    }
    if (c.meta.hp <= 0) this.breakCrate(c);
  }

  private breakCrate(c: B) {
    if (c.meta!.dead) return;
    c.meta!.dead = true;
    const { x, y } = c.position;
    Composite.remove(this.engine.world, c);
    for (let i = 0; i < 12; i++) {
      this.spawn({
        x,
        y,
        vx: rnd(-260, 260),
        vy: rnd(-360, -40),
        g: 700,
        drag: 0.5,
        rot: rnd(0, 6.3),
        vr: rnd(-12, 12),
        life: rnd(0.4, 0.8),
        size: rnd(4, 9),
        color: [KRAFT, KRAFT_D, "#e8c58f"][Math.floor(rnd(0, 3))],
        kind: "chip",
      });
    }
    this.spawn({ x, y, vx: 0, vy: 0, g: 0, drag: 0, life: 0.28, size: 34, color: KRAFT_D, kind: "ring" });
    this.score += 5;
    this.shake = Math.min(this.shake + 4, 18);
    sfx.crack();
    this.pushHud();
  }

  private destroyApple(apple: B, cause: "direct" | "chain" | "fall", ball?: B) {
    const m = apple.meta;
    if (!m || m.dead) return;
    m.dead = true;
    if (m.constraint) Composite.remove(this.engine.world, m.constraint);
    const { x, y } = apple.position;
    Composite.remove(this.engine.world, apple);

    // 连击
    this.combo++;
    this.comboTimer = 2.5;
    this.comboFlash = 1;
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    const mult = Math.min(1 + 0.5 * (this.combo - 1), 4);

    let base = cause === "direct" ? 100 : cause === "chain" ? 60 : 40;
    let bonus = 0;
    let reason = cause === "direct" ? "直击命中" : cause === "chain" ? "连锁反应" : "自由落体";
    if (cause === "direct" && ball && (ball.meta?.bounces || 0) > 0) {
      bonus = Math.min((ball.meta!.bounces || 0) * 30, 150);
      reason = `反弹 ×${ball.meta!.bounces} 命中!`;
      this.bounceHits++;
    }
    const pts = Math.round(((base + bonus) * mult) / 5) * 5;
    this.score += pts;
    this.hits++;
    this.targetsLeft--;

    // 果汁粒子
    for (let i = 0; i < 16; i++) {
      const a = rnd(0, Math.PI * 2);
      const sp = rnd(70, 380);
      this.spawn({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 60,
        g: 640,
        drag: 0.7,
        life: rnd(0.4, 0.85),
        size: rnd(2.5, 5.5),
        color: Math.random() < 0.72 ? "#e5484d" : "#f2836b",
        kind: "dot",
      });
    }
    for (let i = 0; i < 6; i++) {
      this.spawn({
        x,
        y,
        vx: rnd(-160, 160),
        vy: rnd(-300, -80),
        g: 500,
        drag: 0.5,
        rot: rnd(0, 6.3),
        vr: rnd(-8, 8),
        life: rnd(0.4, 0.7),
        size: rnd(3, 5),
        color: "#4c9a52",
        kind: "chip",
      });
    }
    this.spawn({ x, y, vx: 0, vy: 0, g: 0, drag: 0, life: 0.35, size: 46, color: RED, kind: "ring" });
    if (this.combo >= 3) {
      for (let i = 0; i < 10; i++) {
        this.spawn({
          x,
          y: y - 10,
          vx: rnd(-220, 220),
          vy: rnd(-420, -160),
          g: 760,
          drag: 0.4,
          rot: rnd(0, 6.3),
          vr: rnd(-14, 14),
          life: rnd(0.5, 0.9),
          size: rnd(3, 6),
          color: [RED, YELLOW, "#2f7f6f", "#4c9a52"][Math.floor(rnd(0, 4))],
          kind: "confetti",
        });
      }
    }

    this.floaters.push({
      x,
      y: y - 26,
      text: `+${pts}`,
      sub: this.combo > 1 ? `${reason} · 连击 ×${mult.toFixed(1)}` : reason,
      color: RED,
      t: 0,
      max: 1.15,
      size: cause === "direct" ? 30 : 24,
    });

    this.shake = Math.min(this.shake + 8, 22);
    this.freeze = 0.055;
    sfx.pop(this.combo);

    if (!this.recordAnnounced && bestScore() > 0 && this.score > bestScore()) {
      this.recordAnnounced = true;
      this.floaters.push({
        x: this.worldW / 2,
        y: this.worldH * 0.3,
        text: "打破纪录!",
        color: INK,
        t: 0,
        max: 1.6,
        size: 44,
      });
      sfx.best();
    }

    if (this.targetsLeft <= 0) this.waveClearTimer = 0.9;
    this.pushHud();
  }

  private clearWave() {
    const bonus = 60 * this.wave;
    this.score += bonus;
    const gained = 6;
    this.ballsLeft = Math.min(this.ballsLeft + gained, 25);
    this.floaters.push({
      x: this.worldW / 2,
      y: this.worldH * 0.36,
      text: `实验台清空 +${bonus}`,
      sub: `弹药补给 +${gained}`,
      color: "#2f7f6f",
      t: 0,
      max: 1.5,
      size: 34,
    });
    this.wave++;
    this.buildWave(this.wave);
    this.setBanner(`第 ${this.wave} 波`, this.windText());
    sfx.wave();
    this.pushHud();
  }

  private gameOver() {
    this.screen = "over";
    if (this.score > 0) {
      const res = saveScore(this.score, this.wave);
      this.newBestIndex = res.index;
      if (res.index === 0) sfx.best();
    } else {
      this.newBestIndex = -1;
    }
    sfx.over();
    this.pushHud();
  }

  /* ---------------- HUD 同步 ---------------- */
  private pushHud() {
    const snap: HudSnapshot = {
      screen: this.screen,
      score: this.score,
      wave: this.wave,
      balls: this.ballsLeft,
      targets: this.targetsLeft,
      wind: this.wind,
      combo: this.combo,
      comboMult: Math.min(1 + 0.5 * (this.combo - 1), 4),
      comboOn: this.combo > 1 && this.comboTimer > 0,
      shots: this.shots,
      hits: this.hits,
      maxCombo: this.maxCombo,
      bounceHits: this.bounceHits,
      hasFired: this.hasFired,
      banner: this.banner,
      scores: loadScores(),
      newBestIndex: this.newBestIndex,
      best: bestScore(),
    };
    const json = JSON.stringify(snap);
    if (json !== this.lastHudJson) {
      this.lastHudJson = json;
      this.onHud(snap);
    }
  }

  /* ---------------- 主循环 ---------------- */
  private tick(now: number) {
    const dtMs = Math.min(now - this.last, 100);
    this.last = now;
    const dt = dtMs / 1000;

    if (this.screen === "playing") {
      // 键盘瞄准
      if (this.keys.has("ArrowLeft") || this.keys.has("KeyA"))
        this.aimAngle = Math.min(89, this.aimAngle + 58 * dt);
      if (this.keys.has("ArrowRight") || this.keys.has("KeyD"))
        this.aimAngle = Math.max(10, this.aimAngle - 58 * dt);
      if (this.keys.has("ArrowUp") || this.keys.has("KeyW"))
        this.aimPower = Math.min(MAX_LAUNCH, this.aimPower + 620 * dt);
      if (this.keys.has("ArrowDown") || this.keys.has("KeyS"))
        this.aimPower = Math.max(MIN_LAUNCH, this.aimPower - 620 * dt);

      this.cooldown -= dt;
      this.recoil = Math.max(0, this.recoil - dt * 60);
      this.comboFlash = Math.max(0, this.comboFlash - dt * 3);

      if (this.comboTimer > 0) {
        this.comboTimer -= dt;
        if (this.comboTimer <= 0 && this.combo > 0) {
          this.combo = 0;
          this.pushHud();
        }
      }

      // 物理步进（含短暂定帧）
      if (this.freeze > 0) {
        this.freeze -= dt;
      } else {
        this.acc += dtMs;
        let steps = 0;
        while (this.acc >= STEP && steps < 3) {
          Engine.update(this.engine, STEP);
          this.acc -= STEP;
          steps++;
        }
        if (this.acc > STEP * 3) this.acc = 0;
      }

      this.updateBalls(dt);

      // 波次清空 / 结束判定
      if (this.waveClearTimer > 0) {
        this.waveClearTimer -= dt;
        if (this.waveClearTimer <= 0) {
          this.waveClearTimer = -1;
          this.clearWave();
        }
      }
      if (this.ballsLeft <= 0 && this.balls.length === 0 && this.targetsLeft > 0) {
        this.overTimer += dt;
        if (this.overTimer > 0.7) this.gameOver();
      } else {
        this.overTimer = -0.0001;
      }
    } else if (this.screen === "menu") {
      this.acc += dtMs;
      let steps = 0;
      while (this.acc >= STEP && steps < 2) {
        Engine.update(this.engine, STEP);
        this.acc -= STEP;
        steps++;
      }
    }

    // 粒子 & 漂浮文字 & 震屏（渲染层）
    this.updateParticles(dt);
    this.shake *= Math.pow(0.0008, dt);
    if (this.shake < 0.15) this.shake = 0;

    // 风粒子
    if (this.screen === "playing" && Math.abs(this.wind) > 0.001 && this.particles.length < 380) {
      if (Math.random() < 0.35) {
        const dir = Math.sign(this.wind);
        this.spawn({
          x: dir > 0 ? -20 : this.worldW + 20,
          y: rnd(30, this.worldH * 0.7),
          vx: dir * rnd(220, 420),
          vy: rnd(-8, 8),
          g: 0,
          drag: 0,
          life: rnd(0.8, 1.6),
          size: rnd(14, 30),
          color: "#7c8db8",
          kind: "streak",
        });
      }
    }

    this.render();
  }

  private updateBalls(dt: number) {
    // 被击飞出界的苹果按“自由落体”计分，避免卡关
    const all = Composite.allBodies(this.engine.world) as B[];
    for (const b of all) {
      if (
        b.meta?.kind === "apple" &&
        !b.meta.dead &&
        (b.position.x > this.worldW + 130 || b.position.x < -130)
      ) {
        this.destroyApple(b, "fall");
      }
    }
    for (const b of [...this.balls]) {
      if (b.meta?.dead) continue;
      const { x, y } = b.position;
      if (x < -90 || x > this.worldW + 90 || y > this.worldH + 140) {
        this.removeBall(b);
        continue;
      }
      const speed = Math.hypot(b.velocity.x, b.velocity.y);
      if (speed < 0.12) {
        b.meta!.rest = (b.meta!.rest || 0) + dt;
        if (b.meta!.rest > 1.6) {
          this.dust(x, y, 2);
          this.removeBall(b);
          continue;
        }
      } else {
        b.meta!.rest = 0;
      }
    }
  }

  /* ---------------- 粒子 ---------------- */
  private spawn(p: Omit<Particle, "rot" | "vr" | "max"> & Partial<Particle>) {
    if (this.particles.length > 440) this.particles.shift();
    this.particles.push({
      rot: 0,
      vr: 0,
      max: p.life,
      ...p,
    } as Particle);
  }

  private updateParticles(dt: number) {
    const next: Particle[] = [];
    for (const p of this.particles) {
      p.life -= dt;
      if (p.life <= 0) continue;
      p.vy += p.g * dt;
      const dr = Math.max(0, 1 - p.drag * dt);
      p.vx *= dr;
      p.vy *= dr;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      next.push(p);
    }
    this.particles = next;
    for (const f of this.floaters) f.t += dt;
    this.floaters = this.floaters.filter((f) => f.t < f.max);
  }

  /* ---------------- 渲染 ---------------- */
  private render() {
    const { ctx } = this;
    const sx = this.shake ? rnd(-this.shake, this.shake) * 0.5 : 0;
    const sy = this.shake ? rnd(-this.shake, this.shake) * 0.5 : 0;
    ctx.setTransform(this.dpr * this.scale, 0, 0, this.dpr * this.scale, sx, sy);

    this.drawBackground();

    // 绳子
    const bodies = Composite.allBodies(this.engine.world) as B[];
    for (const b of bodies) {
      if (b.meta?.kind === "apple" && b.meta.constraint && b.meta.anchor) {
        const a = b.meta.anchor;
        const sag = Math.max(3, 10 - Math.hypot(b.position.x - a.x, b.position.y - a.y) * 0.02);
        ctx.strokeStyle = INK;
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.quadraticCurveTo(
          (a.x + b.position.x) / 2,
          (a.y + b.position.y) / 2 + sag,
          b.position.x,
          b.position.y - APPLE_R + 2
        );
        ctx.stroke();
      }
    }

    for (const b of bodies) this.drawBody(b);
    for (const b of this.balls) if (!b.meta?.dead) this.drawBall(b);

    this.drawCannon();
    if (this.screen === "playing") this.drawAim();
    this.drawParticles();
    this.drawFloaters();
  }

  private drawBackground() {
    const { ctx } = this;
    const W = this.worldW;
    const H = this.worldH;
    const VW = Math.max(this.viewW, W);
    const VH = Math.max(this.viewH, H);
    ctx.fillStyle = PAPER;
    ctx.fillRect(-60, -60, VW + 120, VH + 120);
    if (this.gridTile) {
      ctx.fillStyle = ctx.createPattern(this.gridTile, "repeat")!;
      ctx.fillRect(-60, -60, VW + 120, VH + 120);
    }

    // 红色页边线 + 装订孔
    ctx.strokeStyle = "rgba(217,58,58,0.4)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(48, -60);
    ctx.lineTo(48, VH + 60);
    ctx.stroke();
    for (let y = 60; y < H; y += 120) {
      ctx.beginPath();
      ctx.arc(22, y, 7, 0, Math.PI * 2);
      ctx.fillStyle = "#e2e8f4";
      ctx.fill();
      ctx.strokeStyle = "rgba(30,42,74,0.25)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // 淡笔迹公式
    ctx.save();
    ctx.globalAlpha = 0.085;
    ctx.fillStyle = INK;
    const scribs: Array<[number, number, string, number, number]> = [
      [0.2, 0.14, "v = v₀ + g·t", -0.05, 26],
      [0.34, 0.3, "Δh = ½·g·t²", 0.04, 22],
      [0.16, 0.52, "Eₖ = ½·m·v²", -0.03, 24],
      [0.42, 0.1, "F = m·a", 0.06, 21],
      [0.62, 0.08, "R = v₀²·sin2θ / g", -0.02, 23],
      [0.3, 0.78, "θ = 45° → R max", 0.03, 22],
    ];
    for (const [rx, ry, text, rot, size] of scribs) {
      ctx.save();
      ctx.translate(rx * W, ry * H);
      ctx.rotate(rot);
      ctx.font = `italic 600 ${size}px "IBM Plex Mono", "Times New Roman", serif`;
      ctx.fillText(text, 0, 0);
      ctx.restore();
    }
    // 抛物线涂鸦
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.setLineDash([7, 7]);
    ctx.beginPath();
    ctx.moveTo(0.1 * W, 0.7 * H);
    ctx.quadraticCurveTo(0.3 * W, 0.28 * H, 0.5 * W, 0.66 * H);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    // 地面（教科书阴影线）
    const gy = this.groundY();
    ctx.fillStyle = "rgba(210,220,240,0.55)";
    ctx.fillRect(-60, gy, VW + 120, VH - gy + 60);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-60, gy);
    ctx.lineTo(VW + 60, gy);
    ctx.stroke();
    ctx.lineWidth = 1.6;
    ctx.globalAlpha = 0.5;
    for (let x = -20; x < VW + 60; x += 20) {
      ctx.beginPath();
      ctx.moveTo(x, gy + 2);
      ctx.lineTo(x - 12, gy + 16);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  private drawBody(b: B) {
    const m = b.meta;
    if (!m || m.kind === "ground" || m.kind === "ball") return;
    const { ctx } = this;
    const { x, y } = b.position;

    if (m.kind === "apple") {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(b.angle * 0.3);
      // 果实
      ctx.beginPath();
      ctx.arc(0, 1, APPLE_R, 0, Math.PI * 2);
      ctx.fillStyle = "#e5484d";
      ctx.fill();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = INK;
      ctx.stroke();
      // 高光
      ctx.beginPath();
      ctx.arc(-5, -4, 5.5, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.fill();
      // 果柄 + 叶
      ctx.strokeStyle = INK;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(0, -APPLE_R + 3);
      ctx.quadraticCurveTo(2, -APPLE_R - 4, 5, -APPLE_R - 6);
      ctx.stroke();
      ctx.save();
      ctx.translate(9, -APPLE_R - 4);
      ctx.rotate(-0.5);
      ctx.beginPath();
      ctx.ellipse(0, 0, 8, 4, 0, 0, Math.PI * 2);
      ctx.fillStyle = "#4c9a52";
      ctx.fill();
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.restore();
      ctx.restore();
      return;
    }

    if (m.kind === "stand") {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(b.angle);
      const vs = b.vertices;
      const w = Math.abs(vs[1].x - vs[0].x) || 10;
      const h = Math.abs(vs[2].y - vs[1].y) || 10;
      ctx.fillStyle = "#3d4d7c";
      ctx.strokeStyle = INK;
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.roundRect(-w / 2, -h / 2, w, h, 3);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
      return;
    }

    // 木箱 / 木板
    const vs = b.vertices;
    const w = Math.hypot(vs[1].x - vs[0].x, vs[1].y - vs[0].y);
    const h = Math.hypot(vs[2].x - vs[1].x, vs[2].y - vs[1].y);
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(b.angle);
    ctx.fillStyle = KRAFT;
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.roundRect(-w / 2, -h / 2, w, h, 4);
    ctx.fill();
    ctx.stroke();
    // 斜角阴影
    ctx.beginPath();
    ctx.moveTo(w / 2 - 4, -h / 2 + 4);
    ctx.lineTo(w / 2 - 4, h / 2 - 4);
    ctx.lineTo(-w / 2 + 4, h / 2 - 4);
    ctx.strokeStyle = "rgba(139,94,38,0.4)";
    ctx.lineWidth = 3;
    ctx.stroke();
    if (m.kind === "crate") {
      ctx.strokeStyle = "rgba(30,42,74,0.5)";
      ctx.lineWidth = 1.4;
      ctx.strokeRect(-w / 2 + 7, -h / 2 + 7, w - 14, h - 14);
      ctx.fillStyle = "rgba(30,42,74,0.5)";
      ctx.font = 'italic 600 17px "IBM Plex Mono", serif';
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("m", 0, 1);
      ctx.textAlign = "left";
      ctx.textBaseline = "alphabetic";
    }
    // 裂纹
    const dmg = (m.maxHp ?? 1) - (m.hp ?? 0);
    if (dmg > 0 && m.seed !== undefined) {
      ctx.strokeStyle = "rgba(60,38,10,0.75)";
      ctx.lineWidth = 1.8;
      const s = m.seed * 100;
      for (let c = 0; c < dmg; c++) {
        ctx.beginPath();
        let px = ((s * (c + 3)) % (w - 16)) - w / 2 + 8;
        let py = -h / 2 + 3;
        ctx.moveTo(px, py);
        for (let i = 0; i < 4; i++) {
          px += ((s * (c + i + 7)) % 14) - 7;
          py += (h - 6) / 4;
          ctx.lineTo(px, py);
        }
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  private drawBall(b: B) {
    const { ctx } = this;
    // 轨迹拖尾
    const hist = (b as B & { trail?: Array<{ x: number; y: number }> }).trail;
    if (!hist) {
      (b as B & { trail?: Array<{ x: number; y: number }> }).trail = [];
    }
    const trail = (b as B & { trail: Array<{ x: number; y: number }> }).trail;
    trail.push({ x: b.position.x, y: b.position.y });
    if (trail.length > 9) trail.shift();
    for (let i = 0; i < trail.length - 1; i++) {
      const t = trail[i];
      ctx.globalAlpha = (i / trail.length) * 0.3;
      ctx.fillStyle = "#24335c";
      ctx.beginPath();
      ctx.arc(t.x, t.y, (i / trail.length) * BALL_R * 0.8, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    const { x, y } = b.position;
    ctx.beginPath();
    ctx.arc(x, y, BALL_R, 0, Math.PI * 2);
    ctx.fillStyle = "#24335c";
    ctx.fill();
    ctx.lineWidth = 2.2;
    ctx.strokeStyle = INK;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(x - 4, y - 4, 3.6, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.75)";
    ctx.fill();
  }

  private drawCannon() {
    const { ctx } = this;
    const { x: cx, y: cy } = this.cannonPos();
    const a = (this.aimAngle * Math.PI) / 180;

    // 量角器刻度盘
    const R = 88;
    const active = this.aiming || this.screen === "playing";
    ctx.save();
    ctx.globalAlpha = this.aiming ? 0.9 : active ? 0.35 : 0.25;
    ctx.strokeStyle = INK;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(cx, cy, R, -Math.PI / 2, 0);
    ctx.stroke();
    for (let d = 0; d <= 90; d += 10) {
      const da = (d * Math.PI) / 180;
      const major = d % 30 === 0;
      const r1 = R - (major ? 10 : 6);
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(da) * r1, cy - Math.sin(da) * r1);
      ctx.lineTo(cx + Math.cos(da) * R, cy - Math.sin(da) * R);
      ctx.stroke();
      if (major && d > 0 && d < 90) {
        ctx.fillStyle = INK;
        ctx.font = '10px "IBM Plex Mono", monospace';
        ctx.fillText(`${d}°`, cx + Math.cos(da) * (R + 7) - 8, cy - Math.sin(da) * (R + 7) + 3);
      }
    }
    // 当前角度红线
    ctx.strokeStyle = RED;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * (R - 14), cy - Math.sin(a) * (R - 14));
    ctx.lineTo(cx + Math.cos(a) * (R + 4), cy - Math.sin(a) * (R + 4));
    ctx.stroke();
    ctx.restore();

    // 炮管
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-a);
    ctx.translate(-this.recoil, 0);
    ctx.fillStyle = "#2c3c6e";
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.roundRect(-14, -13, 84, 26, 8);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = RED;
    ctx.beginPath();
    ctx.roundRect(52, -13, 12, 26, 3);
    ctx.fill();
    ctx.strokeRect(52, -13, 12, 26);
    ctx.restore();

    // 炮座 + 轮子
    ctx.beginPath();
    ctx.moveTo(cx - 30, this.groundY());
    ctx.lineTo(cx - 18, cy - 4);
    ctx.lineTo(cx + 18, cy - 4);
    ctx.lineTo(cx + 30, this.groundY());
    ctx.closePath();
    ctx.fillStyle = "#24335c";
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.6;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, 13, 0, Math.PI * 2);
    ctx.fillStyle = "#2c3c6e";
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = YELLOW;
    ctx.fill();
    ctx.stroke();
  }

  private drawAim() {
    const { ctx } = this;
    const { x: cx, y: cy } = this.cannonPos();
    const a = (this.aimAngle * Math.PI) / 180;
    const v = this.aimPower;
    const mx = cx + Math.cos(a) * 70;
    const my = cy - Math.sin(a) * 70;

    // 初速度矢量箭头
    const alen = 34 + (v / MAX_LAUNCH) * 84;
    const ex = mx + Math.cos(a) * alen;
    const ey = my - Math.sin(a) * alen;
    ctx.strokeStyle = RED;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(mx, my);
    ctx.lineTo(ex, ey);
    ctx.stroke();
    const ha = Math.atan2(ey - my, ex - mx);
    ctx.beginPath();
    ctx.moveTo(ex, ey);
    ctx.lineTo(ex - Math.cos(ha - 0.42) * 12, ey - Math.sin(ha - 0.42) * 12);
    ctx.moveTo(ex, ey);
    ctx.lineTo(ex - Math.cos(ha + 0.42) * 12, ey - Math.sin(ha + 0.42) * 12);
    ctx.stroke();

    // 抛物线预测（含风）
    const g = G_UNITS * 1000;
    const ax = this.wind * 1000;
    let px = mx;
    let py = my;
    let vx = Math.cos(a) * v;
    let vy = -Math.sin(a) * v;
    const dt = 1 / 60;
    const bodies = (Composite.allBodies(this.engine.world) as B[]).filter(
      (b) => b.meta && b.meta.kind !== "ball" && b.meta.kind !== "ground" && !b.isStatic
    );
    const statics = (Composite.allBodies(this.engine.world) as B[]).filter(
      (b) => b.meta && b.meta.kind === "stand"
    );
    let apexY = my;
    let landed = false;
    let landX = mx;
    ctx.fillStyle = RED;
    for (let i = 0; i < 150; i++) {
      vx += ax * dt;
      vy += g * dt;
      px += vx * dt;
      py += vy * dt;
      apexY = Math.min(apexY, py);
      let hit = false;
      const pt = { x: px, y: py };
      for (const b of bodies) {
        if (Bounds.contains(b.bounds, pt) && Vertices.contains(b.vertices, pt)) {
          hit = true;
          break;
        }
      }
      if (!hit) {
        for (const b of statics) {
          if (Bounds.contains(b.bounds, pt) && Vertices.contains(b.vertices, pt)) {
            hit = true;
            break;
          }
        }
      }
      if (hit || py >= this.groundY() - BALL_R || px > this.worldW + 40 || px < -40) {
        landX = px;
        landed = true;
        // 落点标记
        ctx.strokeStyle = RED;
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(px - 8, Math.min(py, this.groundY()) - 8);
        ctx.lineTo(px + 8, Math.min(py, this.groundY()) + 8);
        ctx.moveTo(px + 8, Math.min(py, this.groundY()) - 8);
        ctx.lineTo(px - 8, Math.min(py, this.groundY()) + 8);
        ctx.stroke();
        break;
      }
      if (i % 3 === 0) {
        ctx.globalAlpha = 0.85 - i * 0.004;
        ctx.beginPath();
        ctx.arc(px, py, 2.7, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;

    // 物理读数标签
    const labels: string[] = [
      `v₀ = ${(v / PPM).toFixed(1)} m/s`,
      `θ = ${Math.round(this.aimAngle)}°`,
    ];
    if (landed) labels.push(`R ≈ ${(Math.abs(landX - cx) / PPM).toFixed(1)} m`);
    const hMax = (this.groundY() - apexY) / PPM;
    if (hMax > 0.5) labels.push(`h ≈ ${hMax.toFixed(1)} m`);
    ctx.font = '600 13px "IBM Plex Mono", monospace';
    const lx = Math.min(cx + 10, this.worldW - 150);
    const ly = cy - 128;
    const bw = 132;
    const bh = labels.length * 17 + 12;
    ctx.fillStyle = "rgba(252,253,255,0.9)";
    ctx.strokeStyle = INK;
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.roundRect(lx, ly - bh + 14, bw, bh, 7);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = RED;
    labels.forEach((s, i) => {
      ctx.fillText(s, lx + 10, ly - bh + 14 + 18 + i * 17);
    });
  }

  private drawParticles() {
    const { ctx } = this;
    for (const p of this.particles) {
      const k = p.life / p.max;
      if (p.kind === "dot" || p.kind === "confetti") {
        ctx.globalAlpha = k;
        ctx.fillStyle = p.color;
        if (p.kind === "confetti") {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
          ctx.restore();
        } else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * k, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (p.kind === "chip") {
        ctx.globalAlpha = k;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
        ctx.restore();
      } else if (p.kind === "smoke") {
        ctx.globalAlpha = k * 0.5;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1.6 - k * 0.6), 0, Math.PI * 2);
        ctx.fill();
      } else if (p.kind === "ring") {
        ctx.globalAlpha = k;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (1.3 - k) + 6, 0, Math.PI * 2);
        ctx.stroke();
      } else if (p.kind === "streak") {
        ctx.globalAlpha = 0.16 * k;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 2;
        ctx.setLineDash([10, 8]);
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - Math.sign(p.vx) * p.size * 2.2, p.y);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawFloaters() {
    const { ctx } = this;
    for (const f of this.floaters) {
      const k = f.t / f.max;
      const alpha = k < 0.15 ? k / 0.15 : 1 - Math.max(0, (k - 0.6) / 0.4);
      const y = f.y - k * 46;
      ctx.globalAlpha = Math.max(0, alpha);
      ctx.font = `${f.size}px "ZCOOL KuaiLe", "Noto Sans SC", sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 5;
      ctx.strokeStyle = "rgba(252,253,255,0.92)";
      ctx.strokeText(f.text, f.x, y);
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, f.x, y);
      if (f.sub) {
        ctx.font = '600 13px "IBM Plex Mono", "Noto Sans SC", monospace';
        ctx.strokeText(f.sub, f.x, y + 20);
        ctx.fillStyle = INK;
        ctx.fillText(f.sub, f.x, y + 20);
      }
      ctx.textAlign = "left";
    }
    ctx.globalAlpha = 1;
  }
}
