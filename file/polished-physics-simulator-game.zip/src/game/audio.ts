/* 程序化音效合成 —— 无任何音频资源文件 */

type OscType = OscillatorType;

class SFX {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  muted = false;

  constructor() {
    try {
      this.muted = localStorage.getItem("na-lab-muted") === "1";
    } catch {
      this.muted = false;
    }
  }

  unlock() {
    if (!this.ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.42;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(m: boolean) {
    this.muted = m;
    try {
      localStorage.setItem("na-lab-muted", m ? "1" : "0");
    } catch {
      /* ignore */
    }
  }

  private tone(opts: {
    f0: number;
    f1?: number;
    dur: number;
    type?: OscType;
    vol?: number;
    delay?: number;
  }) {
    if (!this.ctx || !this.master || this.muted) return;
    const { f0, f1 = f0, dur, type = "sine", vol = 0.2, delay = 0 } = opts;
    const t0 = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, f0), t0);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g).connect(this.master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  private noise(opts: { dur: number; vol?: number; freq?: number; q?: number; delay?: number }) {
    if (!this.ctx || !this.master || this.muted) return;
    const { dur, vol = 0.2, freq = 1200, q = 0.8, delay = 0 } = opts;
    const t0 = this.ctx.currentTime + delay;
    const len = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const bp = this.ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = freq;
    bp.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(bp).connect(g).connect(this.master);
    src.start(t0);
  }

  click() {
    this.tone({ f0: 760, f1: 620, dur: 0.05, type: "square", vol: 0.08 });
  }
  launch(power: number) {
    this.tone({ f0: 200 + power * 220, f1: 70, dur: 0.2, type: "sawtooth", vol: 0.16 });
    this.noise({ dur: 0.12, vol: 0.14, freq: 2400, q: 0.6 });
  }
  bounce(v: number) {
    const vol = Math.min(0.2, 0.04 + v * 0.02);
    this.tone({ f0: 150 + v * 26, f1: 90, dur: 0.07, type: "triangle", vol });
  }
  thud(v: number) {
    this.noise({ dur: 0.08, vol: Math.min(0.18, 0.05 + v * 0.015), freq: 500, q: 1 });
    this.tone({ f0: 120, f1: 70, dur: 0.08, type: "triangle", vol: 0.1 });
  }
  crack() {
    this.noise({ dur: 0.14, vol: 0.22, freq: 1800, q: 0.5 });
    this.tone({ f0: 190, f1: 80, dur: 0.13, type: "sawtooth", vol: 0.1 });
  }
  pop(combo: number) {
    this.tone({ f0: 460, f1: 880, dur: 0.09, type: "square", vol: 0.14 });
    const base = 620 * Math.pow(1.09, Math.min(combo, 10));
    this.tone({ f0: base, dur: 0.16, type: "sine", vol: 0.2, delay: 0.04 });
    this.tone({ f0: base * 1.5, dur: 0.2, type: "sine", vol: 0.12, delay: 0.1 });
  }
  wave() {
    [523, 659, 784, 1046].forEach((f, i) =>
      this.tone({ f0: f, dur: 0.14, type: "triangle", vol: 0.16, delay: i * 0.09 })
    );
  }
  best() {
    [660, 880, 990, 1320, 1760].forEach((f, i) =>
      this.tone({ f0: f, dur: 0.12, type: "square", vol: 0.09, delay: i * 0.07 })
    );
  }
  over() {
    [392, 311, 247, 196].forEach((f, i) =>
      this.tone({ f0: f, f1: f * 0.94, dur: 0.24, type: "triangle", vol: 0.16, delay: i * 0.16 })
    );
  }
}

export const sfx = new SFX();
