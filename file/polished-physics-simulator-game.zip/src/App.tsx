import { useEffect, useRef, useState } from "react";
import { PhysicsGame, type HudSnapshot } from "./game/engine";
import { sfx } from "./game/audio";
import { cn } from "./utils/cn";

const initialHud: HudSnapshot = {
  screen: "menu",
  score: 0,
  wave: 1,
  balls: 10,
  targets: 0,
  wind: 0,
  combo: 0,
  comboMult: 1,
  comboOn: false,
  shots: 0,
  hits: 0,
  maxCombo: 0,
  bounceHits: 0,
  hasFired: false,
  banner: null,
  scores: [],
  newBestIndex: -1,
  best: 0,
};

/* ---------------- 图标 ---------------- */
const ic = "inline-block align-[-2px]";
const IconPlay = ({ s = 16 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
    <path d="M7 4.5v15l13-7.5-13-7.5z" />
  </svg>
);
const IconPause = ({ s = 16 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
    <rect x="5" y="4" width="5" height="16" rx="1.5" />
    <rect x="14" y="4" width="5" height="16" rx="1.5" />
  </svg>
);
const IconRestart = ({ s = 16 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round">
    <path d="M20 12a8 8 0 1 1-2.9-6.2" />
    <path d="M20 3v5h-5" />
  </svg>
);
const IconHome = ({ s = 16 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 11.5 12 4l9 7.5" />
    <path d="M6 10v10h12V10" />
  </svg>
);
const IconSound = ({ on, s = 18 }: { on: boolean; s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 9v6h4l5 4V5L8 9H4z" fill="currentColor" stroke="none" />
    {on ? (
      <>
        <path d="M16.5 8.5a5 5 0 0 1 0 7" />
        <path d="M19 6a8.5 8.5 0 0 1 0 12" />
      </>
    ) : (
      <path d="M16 9.5l5 5m0-5-5 5" />
    )}
  </svg>
);
const IconApple = ({ s = 16 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24">
    <circle cx="12" cy="14" r="8" fill="#e5484d" stroke="#1e2a4a" strokeWidth="2" />
    <path d="M12 6c0-2 1-3.4 2.6-4" fill="none" stroke="#1e2a4a" strokeWidth="2" strokeLinecap="round" />
    <ellipse cx="16.5" cy="4.6" rx="3" ry="1.6" fill="#4c9a52" stroke="#1e2a4a" strokeWidth="1.4" transform="rotate(-18 16.5 4.6)" />
    <circle cx="9.2" cy="11.5" r="1.8" fill="rgba(255,255,255,.7)" />
  </svg>
);
const IconBall = ({ s = 14 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="9" fill="#24335c" stroke="#1e2a4a" strokeWidth="2" />
    <circle cx="9" cy="9" r="2.4" fill="rgba(255,255,255,.8)" />
  </svg>
);
const IconWind = ({ dir, s = 18 }: { dir: number; s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" style={{ transform: dir < 0 ? "scaleX(-1)" : undefined }}>
    <path d="M3 8h11a3 3 0 1 0-3-3" />
    <path d="M3 13h15a3 3 0 1 1-3 3" />
    <path d="M3 18h7" />
  </svg>
);
const IconTrophy = ({ s = 18 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M7 4h10v6a5 5 0 0 1-10 0V4z" fill="#ffd23f" />
    <path d="M7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4" />
    <path d="M12 15v3m-4 3h8m-6-3h4l1 3H9l1-3z" />
  </svg>
);
const IconHand = ({ s = 18 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 11V4.5a1.5 1.5 0 0 1 3 0V10m0-4.5a1.5 1.5 0 0 1 3 0V11m0-3.5a1.5 1.5 0 0 1 3 0V13" />
    <path d="M18 13v3a6 6 0 0 1-6 6h-1.6a6 6 0 0 1-4.7-2.3L3 16.4a1.7 1.7 0 0 1 2.5-2.3L7 15.5V7" />
  </svg>
);
const IconKeys = ({ s = 18 }: { s?: number }) => (
  <svg className={ic} width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2.5" y="6" width="19" height="12" rx="2" />
    <path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h.01M18 14h.01M9 14h6" />
  </svg>
);

/* ---------------- 小组件 ---------------- */
function Squiggle() {
  return (
    <svg viewBox="0 0 320 14" className="mt-1 h-3 w-64 md:w-80" preserveAspectRatio="none">
      <path
        d="M3 9c30-6 55 5 82-2s58 4 84-3 55 5 78-1 45 1 68-2"
        fill="none"
        stroke="#d93a3a"
        strokeWidth="4.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

function ScoreTable({
  scores,
  highlight,
  empty,
}: {
  scores: HudSnapshot["scores"];
  highlight: number;
  empty: string;
}) {
  const medal = ["#d93a3a", "#e8842c", "#c9a227"];
  return (
    <div className="overflow-hidden rounded-lg border-2 border-[#1e2a4a]">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="bg-[#1e2a4a] text-left text-[#f3f5fa]">
            <th className="px-3 py-1.5 font-mono2 text-xs font-medium">#</th>
            <th className="px-3 py-1.5 font-mono2 text-xs font-medium">分数</th>
            <th className="px-3 py-1.5 font-mono2 text-xs font-medium">波数</th>
            <th className="px-3 py-1.5 text-right font-mono2 text-xs font-medium">日期</th>
          </tr>
        </thead>
        <tbody>
          {scores.length === 0 && (
            <tr>
              <td colSpan={4} className="px-3 py-5 text-center text-[#48557a]">
                {empty}
              </td>
            </tr>
          )}
          {scores.map((s, i) => (
            <tr
              key={`${s.score}-${s.date}-${i}`}
              className={cn(
                "border-t border-[#dbe4f4] font-mono2",
                i === highlight ? "score-row-new font-bold" : i % 2 ? "bg-[#f6f8fc]" : "bg-white"
              )}
            >
              <td className="px-3 py-1.5 font-bold" style={{ color: medal[i] ?? "#48557a" }}>
                {i + 1}
              </td>
              <td className="px-3 py-1.5 font-bold text-[#1e2a4a]">{s.score.toLocaleString()}</td>
              <td className="px-3 py-1.5 text-[#48557a]">第 {s.wave} 波</td>
              <td className="px-3 py-1.5 text-right text-[#48557a]">{s.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Kbd({ k }: { k: string }) {
  return <kbd>{k}</kbd>;
}

/* ---------------- 主组件 ---------------- */
export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<PhysicsGame | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(initialHud);
  const [muted, setMuted] = useState(sfx.muted);
  const [bannerShown, setBannerShown] = useState<HudSnapshot["banner"]>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const game = new PhysicsGame(canvas, setHud);
    gameRef.current = game;
    game.attach();
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!hud.banner) return;
    setBannerShown(hud.banner);
    const t = setTimeout(() => setBannerShown(null), 1750);
    return () => clearTimeout(t);
  }, [hud.banner]);

  const g = () => gameRef.current;
  const act = (fn: (game: PhysicsGame) => void) => () => {
    sfx.unlock();
    const game = g();
    if (game) fn(game);
  };
  const toggleMute = () => {
    sfx.unlock();
    const next = !muted;
    setMuted(next);
    sfx.setMuted(next);
    if (!next) sfx.click();
  };

  const inGame = hud.screen === "playing" || hud.screen === "paused";
  const windMs = Math.abs(hud.wind * 10);
  const acc = hud.shots > 0 ? Math.round((hud.hits / hud.shots) * 100) : null;

  return (
    <div className="relative h-full w-full overflow-hidden">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full"
        style={{ touchAction: "none" }}
      />

      {/* ============ 顶部 HUD ============ */}
      {inGame && (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex flex-wrap items-start justify-between gap-2 p-2.5 md:p-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="chip py-1.5!">
              <span className="text-[11px] font-bold text-[#48557a]">得分</span>
              <span className="font-mono2 text-lg font-bold leading-none text-[#d93a3a] tabular-nums">
                {hud.score.toLocaleString()}
              </span>
            </div>
            {hud.comboOn && (
              <div
                key={hud.combo}
                className="chip anim-combo border-[#d93a3a]! bg-[#d93a3a]! text-white!"
              >
                <span className="font-display text-sm leading-none">连击</span>
                <span className="font-mono2 text-base font-bold leading-none">
                  ×{hud.comboMult.toFixed(1)}
                </span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="chip">
              <span className="font-display text-sm leading-none">第 {hud.wave} 波</span>
            </div>
            <div className="chip">
              <IconApple s={15} />
              <span className="font-mono2 text-sm font-bold leading-none tabular-nums">
                ×{hud.targets}
              </span>
            </div>
            <div className="chip">
              <IconWind dir={hud.wind} s={17} />
              <span className="font-mono2 text-xs font-bold leading-none">
                {Math.abs(hud.wind) < 0.001 ? "无风" : `${windMs.toFixed(1)} m/s²`}
              </span>
            </div>
            <div className="chip">
              <IconBall s={14} />
              <span className="font-mono2 text-sm font-bold leading-none tabular-nums">
                ×{hud.balls}
              </span>
            </div>
          </div>

          <div className="pointer-events-auto flex items-center gap-2">
            <button
              className="btn btn-ghost icon-btn"
              aria-label="暂停"
              onClick={act((game) => (hud.screen === "playing" ? game.pause() : game.resume()))}
            >
              {hud.screen === "playing" ? <IconPause s={17} /> : <IconPlay s={17} />}
            </button>
            <button className="btn btn-ghost icon-btn" aria-label="声音" onClick={toggleMute}>
              <IconSound on={!muted} />
            </button>
          </div>
        </div>
      )}

      {/* ============ 波次横幅 ============ */}
      {bannerShown && hud.screen === "playing" && (
        <div
          key={bannerShown.id}
          className="pointer-events-none absolute inset-x-0 top-[26%] z-30 flex flex-col items-center"
        >
          <div className="anim-banner text-center">
            <div
              className="font-display text-5xl text-[#1e2a4a] md:text-7xl"
              style={{
                textShadow:
                  "3px 3px 0 rgba(255,210,63,.9), 6px 6px 0 rgba(30,42,74,.25)",
              }}
            >
              {bannerShown.title}
            </div>
            <div className="mt-2 inline-block rounded-lg border-2 border-[#1e2a4a] bg-[#ffd23f] px-4 py-1 font-mono2 text-sm font-bold text-[#1e2a4a] shadow-[3px_3px_0_#1e2a4a]">
              {bannerShown.sub}
            </div>
          </div>
        </div>
      )}

      {/* ============ 底部提示 ============ */}
      {hud.screen === "playing" && !hud.hasFired && (
        <div className="pointer-events-none absolute inset-x-0 bottom-4 z-20 flex justify-center px-3">
          <div className="chip anim-hint rounded-xl! px-4! py-2! text-xs md:text-sm">
            <IconHand s={16} />
            <span>按住拖动瞄准 · 松手发射</span>
            <span className="mx-1 text-[#c6d5ee]">|</span>
            <IconKeys s={16} />
            <span className="hidden sm:inline">
              <Kbd k="A" />
              <Kbd k="D" /> 角度 · <Kbd k="W" />
              <Kbd k="S" /> 力度 · <Kbd k="空格" /> 发射
            </span>
            <span className="sm:hidden">点按也可发射</span>
          </div>
        </div>
      )}

      {/* ============ 开始界面 ============ */}
      {hud.screen === "menu" && (
        <div className="paper-grid-bg absolute inset-0 z-40 overflow-y-auto">
          <div className="mx-auto flex min-h-full max-w-6xl flex-col px-5 py-8 md:px-10">
            <div className="flex items-start justify-between">
              <div className="flex flex-wrap items-center gap-2">
                <span className="chip bg-[#1e2a4a]! text-[#f3f5fa]!">
                  <span className="font-display text-xs tracking-wide">高中物理 · 抛体运动实验</span>
                </span>
                <span className="chip font-mono2 text-[11px] font-bold text-[#48557a]">
                  Matter.js 实时物理 · 60 FPS
                </span>
              </div>
              <button className="btn btn-ghost icon-btn" aria-label="声音" onClick={toggleMute}>
                <IconSound on={!muted} />
              </button>
            </div>

            <div className="mt-8 grid flex-1 items-start gap-10 lg:grid-cols-[1.25fr_1fr]">
              {/* 左：标题区 */}
              <div>
                <div className="flex items-end gap-4">
                  <h1 className="font-display text-[17vw] leading-[0.95] text-[#1e2a4a] sm:text-7xl md:text-8xl">
                    牛顿的苹果
                  </h1>
                  <svg
                    className="anim-wobble mb-3 hidden w-16 md:block"
                    viewBox="0 0 24 24"
                    aria-hidden
                  >
                    <circle cx="12" cy="14" r="8" fill="#e5484d" stroke="#1e2a4a" strokeWidth="1.6" />
                    <path d="M12 6c0-2 1-3.4 2.6-4" fill="none" stroke="#1e2a4a" strokeWidth="1.8" strokeLinecap="round" />
                    <ellipse cx="16.5" cy="4.6" rx="3" ry="1.6" fill="#4c9a52" stroke="#1e2a4a" strokeWidth="1.2" transform="rotate(-18 16.5 4.6)" />
                  </svg>
                </div>
                <Squiggle />
                <p className="mt-1 font-mono2 text-xs font-semibold tracking-[0.22em] text-[#48557a] md:text-sm">
                  NEWTON&apos;S APPLE — PROJECTILE LAB
                </p>
                <p className="mt-5 max-w-xl text-[15px] leading-relaxed text-[#48557a] md:text-base">
                  操纵实验大炮，用<b className="text-[#1e2a4a]">真实的重力、碰撞与反弹</b>砸碎实验台上的苹果。
                  拖拽时红笔会替你画出<b className="text-[#d93a3a]">抛物线预测</b>——就像物理作业本上的那道例题，
                  只是这次，<b className="text-[#1e2a4a]">算对了真的能得分</b>。
                </p>

                <div className="mt-7 flex flex-wrap items-center gap-4">
                  <button
                    className="btn btn-primary px-9 py-4 text-2xl md:text-3xl"
                    onClick={act((game) => game.startGame())}
                  >
                    <IconPlay s={22} />
                    开始实验
                  </button>
                  {hud.best > 0 && (
                    <div className="chip py-2.5!">
                      <IconTrophy s={17} />
                      <span className="text-xs text-[#48557a]">最高分</span>
                      <span className="font-mono2 text-base font-bold text-[#1e2a4a]">
                        {hud.best.toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>

                {/* 操作说明 */}
                <div className="mt-8 grid gap-3 sm:grid-cols-2">
                  <div className="card-paper p-4">
                    <div className="flex items-center gap-2 font-display text-lg text-[#1e2a4a]">
                      <span className="grid h-8 w-8 place-items-center rounded-lg border-2 border-[#1e2a4a] bg-[#ffd23f]">
                        <IconHand s={17} />
                      </span>
                      触屏 / 鼠标
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-[#48557a]">
                      在画面任意处<b className="text-[#1e2a4a]">按住拖动</b>设定方向与力度，
                      <b className="text-[#d93a3a]">松手即发射</b>；轻点按当前参数快速开炮。
                    </p>
                  </div>
                  <div className="card-paper p-4">
                    <div className="flex items-center gap-2 font-display text-lg text-[#1e2a4a]">
                      <span className="grid h-8 w-8 place-items-center rounded-lg border-2 border-[#1e2a4a] bg-[#ffd23f]">
                        <IconKeys s={17} />
                      </span>
                      键盘
                    </div>
                    <p className="mt-2 text-sm leading-relaxed text-[#48557a]">
                      <Kbd k="A" /> <Kbd k="D" /> 调角度，<Kbd k="W" /> <Kbd k="S" /> 调力度，
                      <Kbd k="空格" /> 发射，<Kbd k="P" /> 暂停，<Kbd k="R" /> 重开。
                    </p>
                  </div>
                </div>
              </div>

              {/* 右：榜单 + 规则 */}
              <div className="flex flex-col gap-5">
                <section className="card-paper anim-slide p-4 md:p-5">
                  <div className="mb-3 flex items-center gap-2">
                    <IconTrophy s={20} />
                    <h2 className="font-display text-xl text-[#1e2a4a]">实验成绩单</h2>
                    <span className="ml-auto font-mono2 text-[10px] font-bold tracking-widest text-[#48557a]">
                      TOP 5 · 本机
                    </span>
                  </div>
                  <ScoreTable scores={hud.scores} highlight={-1} empty="虚位以待——来做第一个拿满分的人" />
                </section>

                <section className="card-paper anim-slide p-4 md:p-5" style={{ animationDelay: "0.08s" }}>
                  <h2 className="font-display text-xl text-[#1e2a4a]">计分规则</h2>
                  <ul className="mt-2 space-y-1.5 text-sm text-[#48557a]">
                    <li className="flex items-center gap-2">
                      <IconApple s={15} /> 击中苹果 <b className="font-mono2 text-[#d93a3a]">+100</b>
                      ，2.5 秒内连续命中触发<b className="text-[#1e2a4a]">连击倍率</b>（最高 ×4）
                    </li>
                    <li className="flex items-center gap-2">
                      <IconBall s={13} /> 小球每次反弹后命中 <b className="font-mono2 text-[#d93a3a]">+30</b>
                      /次 —— 几何大师的奖励
                    </li>
                    <li className="flex items-center gap-2">
                      <svg width="15" height="15" viewBox="0 0 24 24" className={ic}>
                        <rect x="3" y="9" width="14" height="11" rx="2" fill="#dca967" stroke="#1e2a4a" strokeWidth="2" />
                        <path d="M17 6l4 4-7 7-4-4 7-7z" fill="#ffd23f" stroke="#1e2a4a" strokeWidth="2" />
                      </svg>
                      砸塌木箱连锁砸中 <b className="font-mono2 text-[#d93a3a]">+60</b>
                      ；苹果摔落地面 <b className="font-mono2 text-[#d93a3a]">+40</b>
                    </li>
                    <li className="flex items-center gap-2">
                      <IconWind dir={1} s={15} /> 第 2 波起开始<b className="text-[#1e2a4a]">刮风</b>
                      ，抛物线预测会帮你把风算进去
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="font-mono2 text-xs font-bold text-[#2f7f6f]">CLEAR</span>
                      清空一波：奖励 <b className="font-mono2 text-[#d93a3a]">60×波数</b> 分，弹药
                      <b className="font-mono2 text-[#1e2a4a]"> +6</b>；弹尽且留有苹果即结束
                    </li>
                  </ul>
                  <p className="mt-3 border-t-2 border-dashed border-[#c6d5ee] pt-2.5 font-formula text-xs text-[#48557a]">
                    实验参数：g = 9.8 m/s² · 恢复系数 e = 0.55 · 空气阻力≈0 · 比例尺 100 px = 1 m
                  </p>
                </section>
              </div>
            </div>

            <p className="mt-8 text-center font-mono2 text-[11px] text-[#9aa7c7]">
              v₀·cosθ 决定射程，v₀·sinθ 决定高度——剩下的交给重力。
            </p>
          </div>
        </div>
      )}

      {/* ============ 暂停 ============ */}
      {hud.screen === "paused" && (
        <div className="anim-fade absolute inset-0 z-40 grid place-items-center bg-[rgba(19,28,51,0.55)] p-4 backdrop-blur-[2px]">
          <div className="card-paper anim-pop w-full max-w-md p-6 md:p-8">
            <p className="font-mono2 text-[11px] font-bold tracking-[0.3em] text-[#48557a]">
              PAUSED
            </p>
            <h2 className="mt-1 font-display text-4xl text-[#1e2a4a] md:text-5xl">暂停中</h2>
            <p className="mt-2 text-sm text-[#48557a]">
              当前：第 <b className="font-mono2 text-[#1e2a4a]">{hud.wave}</b> 波 · 得分{" "}
              <b className="font-mono2 text-[#d93a3a]">{hud.score.toLocaleString()}</b> · 剩余苹果{" "}
              <b className="font-mono2 text-[#1e2a4a]">{hud.targets}</b>
            </p>
            <div className="mt-6 flex flex-col gap-3">
              <button className="btn btn-primary py-3.5 text-xl" onClick={act((game) => game.resume())}>
                <IconPlay s={18} />
                继续实验
                <Kbd k="P" />
              </button>
              <button className="btn btn-yellow py-3 text-lg" onClick={act((game) => game.restart())}>
                <IconRestart s={17} />
                重新开始
                <Kbd k="R" />
              </button>
              <button className="btn btn-ghost py-3 text-lg" onClick={act((game) => game.toMenu())}>
                <IconHome s={17} />
                返回主页
              </button>
            </div>
            <p className="mt-5 text-center font-formula text-xs text-[#48557a]">
              休息时苹果不会自己掉下来——惯性定律。
            </p>
          </div>
        </div>
      )}

      {/* ============ 结束 ============ */}
      {hud.screen === "over" && (
        <div className="anim-fade absolute inset-0 z-40 overflow-y-auto bg-[rgba(19,28,51,0.6)]">
          <div className="mx-auto flex min-h-full max-w-3xl items-start justify-center p-4 py-8 md:py-12">
            <div className="card-paper anim-pop relative w-full p-6 md:p-8">
              {hud.newBestIndex === 0 && hud.score > 0 && (
                <div className="anim-stamp pointer-events-none absolute -right-3 -top-5 rounded-lg border-4 border-[#d93a3a] bg-[rgba(255,255,255,0.85)] px-4 py-1.5 font-display text-2xl text-[#d93a3a] md:-right-6">
                  新纪录!
                </div>
              )}
              <p className="font-mono2 text-[11px] font-bold tracking-[0.3em] text-[#48557a]">
                LAB REPORT
              </p>
              <div className="flex flex-wrap items-end justify-between gap-3">
                <h2 className="font-display text-5xl text-[#1e2a4a] md:text-6xl">实验结束</h2>
                <div className="text-right">
                  <p className="text-xs font-bold text-[#48557a]">最终得分</p>
                  <p className="font-mono2 text-4xl font-bold leading-tight text-[#d93a3a] tabular-nums md:text-5xl">
                    {hud.score.toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                {[
                  ["推进波数", `第 ${hud.wave} 波`],
                  ["命中 / 发射", `${hud.hits} / ${hud.shots}`],
                  ["命中率", acc === null ? "—" : `${acc}%`],
                  ["最大连击", hud.maxCombo > 0 ? `×${Math.min(1 + 0.5 * (hud.maxCombo - 1), 4).toFixed(1)}` : "—"],
                ].map(([label, val]) => (
                  <div
                    key={label}
                    className="rounded-lg border-2 border-[#1e2a4a] bg-[#f6f8fc] px-3 py-2 shadow-[3px_3px_0_rgba(30,42,74,0.9)]"
                  >
                    <p className="text-[11px] font-bold text-[#48557a]">{label}</p>
                    <p className="font-mono2 text-lg font-bold text-[#1e2a4a]">{val}</p>
                  </div>
                ))}
              </div>
              {hud.bounceHits > 0 && (
                <p className="mt-3 font-mono2 text-xs font-bold text-[#2f7f6f]">
                  ★ 反弹命中 {hud.bounceHits} 次——你已掌握入射角等于反射角的精髓
                </p>
              )}

              <div className="mt-6 grid gap-6 md:grid-cols-[1fr_auto] md:items-start">
                <div className="flex flex-col gap-3">
                  <button className="btn btn-primary py-4 text-2xl" onClick={act((game) => game.restart())}>
                    <IconRestart s={20} />
                    再来一次
                    <Kbd k="R" />
                  </button>
                  <button className="btn btn-ghost py-3 text-lg" onClick={act((game) => game.toMenu())}>
                    <IconHome s={17} />
                    返回主页
                  </button>
                </div>
                <div className="w-full md:w-72">
                  <div className="mb-2 flex items-center gap-2">
                    <IconTrophy s={18} />
                    <h3 className="font-display text-lg text-[#1e2a4a]">成绩单</h3>
                  </div>
                  <ScoreTable
                    scores={hud.scores}
                    highlight={hud.newBestIndex}
                    empty="暂无记录"
                  />
                </div>
              </div>

              <p className="mt-5 text-center font-formula text-xs text-[#48557a]">
                误差分析：苹果的位置误差为 0 —— 它们全都被你砸中了。
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
